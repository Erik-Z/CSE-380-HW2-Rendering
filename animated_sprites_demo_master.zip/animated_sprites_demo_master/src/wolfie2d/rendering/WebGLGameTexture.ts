export class WebGLGameTexture {
    public webGLTextureId: number;
    public webGLTexture: WebGLTexture;
    public image: HTMLImageElement;
    public width : number;
    public height : number;
}